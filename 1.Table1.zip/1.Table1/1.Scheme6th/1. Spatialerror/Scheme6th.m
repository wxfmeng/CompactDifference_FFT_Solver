%% Table 1: �ռ������ײ��� Scheme A (���׸�ʽ)
clc; clear;

alf1=1; bet1=1; gam1=1; eta1=1;
XL=0; XR=1;
tfinal=1;

% ���¸�ʽϵ��
a1=14/15; a2=1/15; a3=4/5; a4=1/5;
b1=1/5; b2=3/5; b3=2/15; b4=11/15;

% �����ԵĿռ䲽������μ��룩
h_list = [1/5, 1/10, 1/20];

fprintf('\nTable 1: Spatial convergence for Scheme A\n');
fprintf('---------------------------------------------------------------------------------------------\n');
fprintf('  h       tau         ||e||_2              rate      ||e||_��              rate      CPU(s)    Iter\n');
fprintf('---------------------------------------------------------------------------------------------\n');

prev_L2 = [];
prev_Linf = [];

tau = 0.0001;

for hidx = 1:length(h_list)
    h = h_list(hidx);  
    M = ceil((XR-XL)/h);
    M1 = M + 1;
    T = ceil(tfinal/tau);
    T1 = T + 1;
    
    x = zeros(1, M1);
    for j = 1:M1
        x(j) = XL + (j-1)*h;
    end
    t = zeros(1, T1);
    for n = 1:T1
        t(n) = (n-1)*tau;
    end
    
    % ��ȷ���Դ��
    uexact = zeros(1, M1);
    f = zeros(M1, T1);
    for j = 1:M1
        uexact(j) = sin(2*pi*x(j)) * exp(-t(T1));
        for n = 1:T1
            f(j,n) = exp(-t(n)) * (2*pi*cos(2*pi*x(j)) - sin(2*pi*x(j)) ...
                     + pi*exp(-t(n))*sin(4*pi*x(j)));
        end
    end
    
    % ��ֵ
    u = zeros(M1, T1);
    for j = 1:M1
        u(j,1) = sin(2*pi*x(j));
    end
    
    % ��������
    A1X = toeplitz([b2; b1; zeros(M-3,1); b1]);
    DXhat = toeplitz([0; -1; zeros(M-3,1); 1], [0; 1; zeros(M-3,1); -1]) / (2*h);
    DXddot = toeplitz([0; 0; -1; zeros(M-5,1); 1; 0], [0; 0; 1; zeros(M-5,1); -1; 0]) / (4*h);
    D1X = a1*DXhat + a2*DXddot;
    
    A2X = toeplitz([b4; b3; zeros(M-3,1); b3]);
    DX2 = toeplitz([-2; 1; zeros(M-3,1); 1]) / (h^2);
    DXhat2 = toeplitz([-2; 0; 1; zeros(M-5,1); 1; 0]) / (4*h^2);
    D2X = a3*DX2 + a4*DXhat2;
    
    I = eye(M);
    H1D1X = A1X \ D1X;
    H2D2X = A2X \ D2X;
    
    temp = 2/tau * (I - alf1*H2D2X);
    temp1 = temp - bet1*H2D2X + gam1*H1D1X;
    
    total_iter = 0;
    tic;
    for n = 1:T
        Gf = (f(1:M,n) + f(1:M,n+1)) / 2;
        if n == 1
            w = zeros(M, 1);
            w(:,1) = u(1:M,n);
        else
            w = zeros(M, 1);
            w(:,1) = 3/2 * u(1:M,n) - 1/2 * u(1:M,n-1);
        end
        
        for k = 1:1000
            temp2 = eta1/3 * (diag(w(:,k))*H1D1X + H1D1X*diag(w(:,k)));
            w(:,k+1) = temp1 \ (temp*u(1:M,n) - temp2*w(:,k) + Gf);
            if norm(w(:,k+1) - w(:,k), inf) < 1.0e-12
                break;
            end
        end
        total_iter = total_iter + k;
        u(1:M, n+1) = 2 * w(:,k+1) - u(1:M,n);
    end
    cpu_time = toc;
    avg_iter = round(total_iter / T);
    
    % �������
    uexact_end = sin(2*pi*x) * exp(-t(T1));
    error = u(:, T1)' - uexact_end;
    L2err = sqrt(h * sum(error.^2));
    Linferr = norm(error, inf);
    
    % ������
    if hidx == 1
        rate_L2 = 0;
        rate_Linf = 0;
    else
        rate_L2 = log2(prev_L2 / L2err);
        rate_Linf = log2(prev_Linf / Linferr);
    end
    prev_L2 = L2err;
    prev_Linf = Linferr;
    
 % ���
    if hidx == 1
        % ��һ�в����������ף��� '-' ռλ
        fprintf('  %5.3f   %8.1e   %.15e   %6s   %.15e   %6s   %8.3f   %5.1f\n', ...
                h, tau, L2err, '-', Linferr, '-', cpu_time, avg_iter);
    else
        fprintf('  %5.3f   %8.1e   %.15e   %6.4f   %.15e   %6.4f   %8.3f   %5.1f\n', ...
                h, tau, L2err, rate_L2, Linferr, rate_Linf, cpu_time, avg_iter);
    end
end

fprintf('---------------------------------------------------------------------------------------------\n');