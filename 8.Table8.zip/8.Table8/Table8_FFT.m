% Table8_FFT.m
clc; clear; close all;

alpha = 1; beta = 1; gamma = 1; eta = -1;
tfinal = 1;
h = pi/64;                     % �̶���ϸ�ռ�����

tau_list = [1/4, 1/8, 1/16, 1/32];   % ʱ�䲽���б�

u_exact = @(x,y,t) t .* sin(x+y);
f_source = @(x,y,t) (3 + 2*t - 2*t.^2 .* cos(x+y)) .* sin(x+y) + 2*t .* cos(x+y);

fprintf('\nTable 8: Temporal convergence for 2D BBMB equation (FFT solver, h=pi/64)\n');
fprintf('=================================================================\n');


M = ceil(2*pi / h);
x = linspace(0, 2*pi, M+1);
x = x(1:end-1)';
y = x;
[X, Y] = meshgrid(x, y);

kx = 2*pi * (0:M-1) / M;
ky = kx;
[KX, KY] = meshgrid(kx, ky);

% �ֱ�� Scheme A �� B Ԥ��������ֵ
for scheme = {'A', 'B'}
    if strcmp(scheme{1}, 'A')
        a1=14/15; a2=1/15; a3=4/5; a4=1/5;
        b1=1/5;  b2=3/5;  b3=2/15; b4=11/15;
        
        denom1x = b2 + 2*b1*cos(KX);
        Lambda1x = 1i * ( a1*(1/h)*sin(KX) + a2*(1/(2*h))*sin(2*KX) ) ./ denom1x;
        denom2x = b4 + 2*b3*cos(KX);
        Lambda2x = -( a3*(4/h^2)*sin(KX/2).^2 + a4*(1/h^2)*sin(KX).^2 ) ./ denom2x;
        
        denom1y = b2 + 2*b1*cos(KY);
        Lambda1y = 1i * ( a1*(1/h)*sin(KY) + a2*(1/(2*h))*sin(2*KY) ) ./ denom1y;
        denom2y = b4 + 2*b3*cos(KY);
        Lambda2y = -( a3*(4/h^2)*sin(KY/2).^2 + a4*(1/h^2)*sin(KY).^2 ) ./ denom2y;
    else % Scheme B
        a5=16/21; a6=5/21; a7=32/63; a8=31/63;
        b5=1/70;  b6=8/35;  b7=18/35; b8=23/3780; b9=172/945; b10=131/210;
        
        denom1x = b7 + 2*b6*cos(KX) + 2*b5*cos(2*KX);
        Lambda1x = 1i * ( a5*(1/h)*sin(KX) + a6*(1/(2*h))*sin(2*KX) ) ./ denom1x;
        denom2x = b10 + 2*b9*cos(KX) + 2*b8*cos(2*KX);
        Lambda2x = -( a7*(4/h^2)*sin(KX/2).^2 + a8*(1/h^2)*sin(KX).^2 ) ./ denom2x;
        
        denom1y = b7 + 2*b6*cos(KY) + 2*b5*cos(2*KY);
        Lambda1y = 1i * ( a5*(1/h)*sin(KY) + a6*(1/(2*h))*sin(2*KY) ) ./ denom1y;
        denom2y = b10 + 2*b9*cos(KY) + 2*b8*cos(2*KY);
        Lambda2y = -( a7*(4/h^2)*sin(KY/2).^2 + a8*(1/h^2)*sin(KY).^2 ) ./ denom2y;
    end
    
    Lambda_L = Lambda2x + Lambda2y;
    Lambda_M = Lambda1x + Lambda1y;
    
    % ��ÿ�� tau ���в���
    fprintf('\nScheme %s\n', scheme{1});
    fprintf('------------------------------------------------------------\n');
    fprintf('  tau     ||e||_F            rate      ||e||_{F,��}        rate      CPU(s)\n');
    fprintf('------------------------------------------------------------\n');
    
    prev_L2 = NaN;
    prev_Linf = NaN;
    
    for tidx = 1:length(tau_list)
        tau = tau_list(tidx);
        Nt = round(tfinal / tau);
        t = (0:Nt) * tau;
        
        % Ƶ��ϵ������������ tau��
        Cl = 1/tau - (alpha/tau)*Lambda_L - (beta/2)*Lambda_L + (gamma/2)*Lambda_M;
        Cr = 1/tau - (alpha/tau)*Lambda_L + (beta/2)*Lambda_L - (gamma/2)*Lambda_M;
        
        % ��ʼ��
        U_tilde = fft2(zeros(M,M));
        U_tilde_prev1 = U_tilde;
        U_tilde_prev2 = U_tilde;
        
        total_iter = 0;
        tic;
        for n = 1:Nt
            f_n   = f_source(X, Y, t(n));
            f_np1 = f_source(X, Y, t(n+1));
            f_avg = (f_n + f_np1) / 2;
            F_avg = fft2(f_avg);
            
            U_n_phys = real(ifft2(U_tilde_prev1));
            
            if n == 1
                U_tilde_old = U_tilde;
            else
                U_tilde_old = 2*U_tilde_prev1 - U_tilde_prev2;
            end
            
            for iter = 1:1000
                U_guess_phys = real(ifft2(U_tilde_old));
                U_half_phys = 0.5 * (U_guess_phys + U_n_phys);
                
                L1U_half_phys = real(ifft2(Lambda_M .* fft2(U_half_phys)));
                U2_half_phys = U_half_phys.^2;
                L1U2_half_phys = real(ifft2(Lambda_M .* fft2(U2_half_phys)));
                Phi_phys = (1/3) * ( U_half_phys .* L1U_half_phys + L1U2_half_phys );
                Phi_tilde = fft2(Phi_phys);
                
                U_tilde_new = ( Cr .* U_tilde_prev1 - eta * Phi_tilde + F_avg ) ./ Cl;
                U_new_phys = real(ifft2(U_tilde_new));
                %err_norm = norm(U_new_phys - U_guess_phys, 'fro');
                err_norm = sqrt(h^2 * sum(sum((U_new_phys - U_guess_phys).^2)));
                if err_norm < 1e-14 && iter > 2
                    break;
                end
                U_tilde_old = U_tilde_new;
            end
            total_iter = total_iter + iter;
            
            U_tilde_prev2 = U_tilde_prev1;
            U_tilde_prev1 = U_tilde_new;
            if n == 1
                U_tilde = U_tilde_new;
            end
        end
        cpu_time = toc;
        avg_iter = total_iter / Nt;   
        
        % �������
        U_final = real(ifft2(U_tilde_prev1));
        u_exact_final = u_exact(X, Y, tfinal);
        err = U_final - u_exact_final;
        L2err = sqrt( h^2 * sum(err(:).^2) );
        Linferr = max(abs(err(:)));
        
        if isnan(prev_L2)
            rate_L2 = '-';
            rate_Linf = '-';
        else
            rate_L2 = log2(prev_L2 / L2err);
            rate_Linf = log2(prev_Linf / Linferr);
        end
        prev_L2 = L2err;
        prev_Linf = Linferr;
        
        if tidx == 1
            fprintf('  %4.2f   %.15e   %6s   %.15e   %6s   %8.3f\n', ...
                    tau, L2err, '-', Linferr, '-', cpu_time);
        else
            fprintf('  %4.2f   %.15e   %6.4f   %.15e   %6.4f   %8.3f\n', ...
                    tau, L2err, rate_L2, Linferr, rate_Linf, cpu_time);
        end
    end
    fprintf('------------------------------------------------------------\n');
end

fprintf('\n������ɡ�\n');