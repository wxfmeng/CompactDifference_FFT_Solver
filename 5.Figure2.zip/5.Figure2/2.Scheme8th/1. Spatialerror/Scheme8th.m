function Scheme8th
clc;clear;
tic;
alf1=1;bet1=1;gam1=1;eta1=1;
XL=-20;XR=30;h=0.25;
tau=0.1;tfinal=20;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Start the iterations%%
a5=16/21;a6=5/21;a7=32/63;a8=31/63;
b5=1/70;b6=8/35;b7=18/35;b8=23/3780;b9=172/945;b10=131/210;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M=ceil((XR-XL)/h);M1=M+1;
T=ceil(tfinal/tau);T1=T+1;
for j=1:M1
    x(j)=XL+(j-1)*h;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for n=1:T1
    t(n)=(n-1)*tau;
end
%%Initial condition
for j=1:M1
    u(j,1)=sech(x(j));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
B1X=toeplitz([b7;b6;b5;zeros(M-5,1);b5;b6]);%һ�׵�����������B1X
DXhat=toeplitz([0;-1;zeros(M-3,1);1],[0;1;zeros(M-3,1);-1])/(2*h);%һ�׵������Ϊ2h���Ĳ�������
DXddot=toeplitz([0;0;-1;zeros(M-5,1);1;0],[0;0;1;zeros(M-5,1);-1;0])/(4*h);%һ�׵������Ϊ4h���Ĳ�������
D3X=a5*DXhat+a6*DXddot;%һ�׵����������Ĳ����������D1X
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
B2X=toeplitz([b10;b9;b8;zeros(M-5,1);b8;b9]);%���׵�����������B2X
DX2=toeplitz([-2;1;zeros(M-3,1);1])/(h^2);%���׵������Ϊ2h���Ĳ�������
DXhat2=toeplitz([-2;0;1;zeros(M-5,1);1;0])/(4*h^2);%���׵������Ϊ4h���Ĳ�������
D4X=a7*DX2+a8*DXhat2;%���׵����������Ĳ����������D2X
%% Operator matrix
I=eye(M);
Qn=zeros(1,T1);%mass
En=zeros(1,T1);%energy
%%%%%%%%%%%%%%%%%%%%
Qn(1)=h*sum(u(1:M,1));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
DX=1/h*toeplitz([-1;zeros(M-2,1);1],[-1,1,zeros(1,M-2)]);%һ�׵�����ǰ��������
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Q4X=chol(inv(B2X));
En1=u(1:M,1)'*u(1:M,1);En2=(Q4X*DX*u(1:M,1))'*(Q4X*DX*u(1:M,1));En3=(Q4X*DXhat*u(1:M,1))'*(Q4X*DXhat*u(1:M,1));
En(1)=h*(En1+alf1*(a7*En2+a8*En3));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
H3D3X=B1X\D3X;%һ������H3XD3X
H4D4X=B2X\D4X;%��������H4XD4X
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
temp=2/tau*(I-alf1*H4D4X);
temp1=temp-bet1*H4D4X+gam1*H3D3X;%��˲���
for n=1:T
    if n==1
        w(:,1)=u(1:M,n);
    else
        w(:,1)=3/2*u(1:M,n)-1/2*u(1:M,n-1);
    end
        for k=1:1000
            temp2=eta1/3*(diag(w(:,k))*H3D3X+H3D3X*diag(w(:,k)));%�������
            w(:,k+1)=temp1\(temp*u(1:M,n)-temp2*w(:,k));
            if norm(w(:,k+1)-w(:,k),inf)<1.0e-14
                break;
            end
        end
        u(1:M,n+1)=2*w(:,k+1)-u(1:M,n); 
        Qn(n+1)=h*sum(u(1:M,n+1));
        En1=u(1:M,n+1)'*u(1:M,n+1);En2=(Q4X*DX*u(1:M,n+1))'*(Q4X*DX*u(1:M,n+1));En3=(Q4X*DXhat*u(1:M,n+1))'*(Q4X*DXhat*u(1:M,n+1));
        En(n+1)=h*(En1+alf1*(a7*En2+a8*En3));
end
toc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1)
mesh(x,t,u')
xlabel('x');
ylabel('t');
zlabel('U');
view(40,20)
axis([XL XR 0 tfinal 0 1.0])
title('Scheme B');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(2);
plot(x,u(:,1),'-',x,u(:,round(T/5)+1),'-',x,u(:,round(2*T/5)+1),'-',x,u(:,round(3*T/5)+1),'-',x,u(:,round(4*T/5)+1),'-',x,u(:,T1),'-' ,'LineWidth',1.5);
xlabel('x');
ylabel('U');
legend('T=0','T=4','T=8','T=12','T=16','T=20')
title('Scheme B');xlabel('x');ylabel('U^n');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ================== figure ==========================================
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ma=[Qn(1),Qn(round(T/20)+1),Qn(round(2*T/20)+1),Qn(round(3*T/20)+1),Qn(round(4*T/20)+1),Qn(round(5*T/20)+1),Qn(round(6*T/20)+1),Qn(round(7*T/20)+1),Qn(round(8*T/20)+1),...
    Qn(round(9*T/20)+1),Qn(round(10*T/20)+1),Qn(round(11*T/20)+1),Qn(round(12*T/20)+1),Qn(round(13*T/20)+1),Qn(round(14*T/20)+1),...
    Qn(round(15*T/20)+1),Qn(round(16*T/20)+1),Qn(round(17*T/20)+1),Qn(round(18*T/20)+1),Qn(round(19*T/20)+1),Qn(T1)]
en=[En(1),En(round(T/20)+1),En(round(2*T/20)+1),En(round(3*T/20)+1),En(round(4*T/20)+1),En(round(5*T/20)+1),En(round(6*T/20)+1),En(round(7*T/20)+1),En(round(8*T/20)+1),...
    En(round(9*T/20)+1),En(round(10*T/20)+1),En(round(11*T/20)+1),En(round(12*T/20)+1),En(round(13*T/20)+1),En(round(14*T/20)+1),...
    En(round(15*T/20)+1),En(round(16*T/20)+1),En(round(17*T/20)+1),En(round(18*T/20)+1),En(round(19*T/20)+1),En(T1)]
t1=[0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20];

figure(3);
plot(t1,ma,'-or','LineWidth',1.5);
%axis([0,tfinal,0.68,1.26])
xlabel('t');
ylabel('Q^{n}');
title('Scheme B');

figure(4);
plot(t1,en,'-or','LineWidth',1.5);
%axis([0,tfinal,0.68,1.26])
xlabel('t');
ylabel('E^{n}');
title('Scheme B');

figure(5);
plot(t1,ma,'r-O',t1,en,'b-o','LineWidth',1.5);
title('Scheme B');xlabel('t');ylabel('M_{I}^n, E_{I}^n');
legend('M_{I}^n','E_{I}^n')
