function rate1
clc;
%Elapsed time is 1.644000 seconds.
a1=1.378439146865167e-004;
a2=2.949343416047690e-005;

%Elapsed time is 13.789000 seconds.
b1=4.370626953408578e-007;
b2=9.897164976457873e-008;

A1=log(a1/b1)/log(2)
B1=log(a2/b2)/log(2)