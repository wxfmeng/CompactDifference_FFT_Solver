function Scheme6th
clc;clear;
tic;
alf1=1;bet1=1;gam1=1;eta1=1;
XL=0;XR=1;h=0.01;
tau=h;tfinal=10;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Start the iterations%%
a1=14/15;a2=1/15;a3=4/5;a4=1/5;
b1=1/5;b2=3/5;b3=2/15;b4=11/15;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M=ceil((XR-XL)/h);M1=M+1;
T=ceil(tfinal/tau);T1=T+1;
for j=1:M1
    x(j)=XL+(j-1)*h;
end
for n=1:T1
    t(n)=(n-1)*tau;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Exact Solution
for j=1:M1
    for n=1:T1
        f(j,n)=exp(-t(n))*(2*pi*cos(2*pi*x(j))-sin(2*pi*x(j))+pi*exp(-t(n))*sin(4*pi*x(j)));
        uexact(j,n)=sin(2*pi*x(j))*exp(-t(n));
    end
end
%%Initial condition
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:M1
    u(j,1)=sin(2*pi*x(j));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
A1X=toeplitz([b2;b1;zeros(M-3,1);b1]);%һ�׵�����������A1X
DXhat=toeplitz([0;-1;zeros(M-3,1);1],[0;1;zeros(M-3,1);-1])/(2*h);%һ�׵������Ϊ2h���Ĳ�������
DXddot=toeplitz([0;0;-1;zeros(M-5,1);1;0],[0;0;1;zeros(M-5,1);-1;0])/(4*h);%һ�׵������Ϊ4h���Ĳ�������
D1X=a1*DXhat+a2*DXddot;%һ�׵����������Ĳ����������D1X
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
A2X=toeplitz([b4;b3;zeros(M-3,1);b3]);%���׵�����������A2X
DX2=toeplitz([-2;1;zeros(M-3,1);1])/(h^2);%���׵������Ϊ2h���Ĳ�������
DXhat2=toeplitz([-2;0;1;zeros(M-5,1);1;0])/(4*h^2);%���׵������Ϊ4h���Ĳ�������
D2X=a3*DX2+a4*DXhat2;%���׵����������Ĳ����������D2X
%% Operator matrix
I=eye(M);
Qn=zeros(1,T1);%mass
En=zeros(1,T1);%energy
%%%%%%%%%%%%%%%%%%%%
Qn(1)=h*sum(u(1:M,1));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
DX=1/h*toeplitz([-1;zeros(M-2,1);1],[-1,1,zeros(1,M-2)]);%һ�׵�����ǰ��������
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Q2X=chol(inv(A2X));
En1=u(1:M,1)'*u(1:M,1);En2=(Q2X*DX*u(1:M,1))'*(Q2X*DX*u(1:M,1));En3=(Q2X*DXhat*u(1:M,1))'*(Q2X*DXhat*u(1:M,1));
En(1)=h*(En1+alf1*(a3*En2+a4*En3));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
H1D1X=A1X\D1X;%һ������H1XD1X
H2D2X=A2X\D2X;%��������H2XD2X
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
temp=2/tau*(I-alf1*H2D2X);
temp1=temp-bet1*H2D2X+gam1*H1D1X;%��˲���
for n=1:T
    Gf=(f(1:M,n)+f(1:M,n+1))/2;
    if n==1
        w(:,1)=u(1:M,n);
    else
        w(:,1)=3/2*u(1:M,n)-1/2*u(1:M,n-1);
    end
        for k=1:1000
            temp2=eta1/3*(diag(w(:,k))*H1D1X+H1D1X*diag(w(:,k)));%�������
            w(:,k+1)=temp1\(temp*u(1:M,n)-temp2*w(:,k)+Gf);
            if norm(w(:,k+1)-w(:,k),inf)<1.0e-14
                break;
            end
        end
        u(1:M,n+1)=2*w(:,k+1)-u(1:M,n); 
        Qn(n+1)=h*sum(u(1:M,n+1));
        En1=u(1:M,n+1)'*u(1:M,n+1);En2=(Q2X*DX*u(1:M,n+1))'*(Q2X*DX*u(1:M,n+1));En3=(Q2X*DXhat*u(1:M,n+1))'*(Q2X*DXhat*u(1:M,n+1));
        En(n+1)=h*(En1+alf1*(a3*En2+a4*En3));
end
toc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1)
mesh(x,t,u')
xlabel('x');
ylabel('t');
zlabel('U');
view(40,20)
%axis([XL XR 0 tfinal 0 0.15])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S=0;
for j=1:M1
    b(j)=u(j,T1);
    buexact(j)=uexact(j,T1);
    erroru(j)=abs(b(j)-buexact(j));
    S=S+erroru(j)^2; 
end
norm2u=sqrt(h*S)
norminfu=norm(erroru,inf)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(2)
plot(x,b,'*r',x,buexact,'-k');
ylabel('U,u');
xlabel('x');
%axis([XL XR 0 0.16])
legend('Numerical solution U','Solitary solution u',2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(3)
plot(x,erroru,'-r');
ylabel('Error u');
xlabel('x');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(4);
plot(x,u(:,1),'-',x,u(:,ceil(T/5+1)),'*-',x,u(:,ceil(2*T/5+1)),'p-',x,u(:,ceil(3*T/5+1)),'o-',x,u(:,ceil(4*T/5+1)),'s-',x,u(:,T1),'-','LineWidth',1.5);
xlabel('x');
ylabel('U');
legend('T=0','T=2','T=4','T=6','T=8','T=10');
%axis([XL,XR,0,0.601])
title('Scheme A');xlabel('x');ylabel('U^n');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
t1=0:2:tfinal;
qn=[Qn(1),Qn(ceil(T/5+1)),Qn(ceil(2*T/5+1)),Qn(ceil(3*T/5+1)),Qn(ceil(4*T/5+1)),Qn(T+1)];
en=[En(1),En(ceil(T/5+1)),En(ceil(2*T/5+1)),En(ceil(3*T/5+1)),En(ceil(4*T/5+1)),En(T+1)];

figure(5);
plot(t1,qn,'-or','LineWidth',1.5);
%axis([0,tfinal,0.68,1.26])
xlabel('t');
ylabel('Q^{n}');
title('Scheme A');

figure(6);
plot(t1,en,'-or','LineWidth',1.5);
%axis([0,tfinal,0.68,1.26])
xlabel('t');
ylabel('E^{n}');
title('Scheme A');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:M1
    for n=1:T1
        err(j,n)=abs(uexact(j,n)-u(j,n));
    end
end
figure(7)
mesh(x,t,err')
xlabel('x');
ylabel('t');
zlabel('Absolute Error');
%axis([-25 25 0 30 0 0.00005])