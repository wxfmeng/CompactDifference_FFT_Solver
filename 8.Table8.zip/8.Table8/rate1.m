function rate1
clc;
%Elapsed time is 1.644000 seconds.
a1=1.021467449248109e-003;
a2=2.480996888730713e-004;

%Elapsed time is 13.789000 seconds.
b1=1.231174926381525e-005;
b2=3.212940394958785e-006;

A1=log(a1/b1)/log(2)
B1=log(a2/b2)/log(2)