function BBMBEquationA
clear all; close all; clc;
tic;
% Parameters
alpha=1;beta=1;gamma=1;eta=-1;
XL=0;XR=2*pi;h=pi/16;
M=ceil((XR-XL)/h);M1=M+1;
% Spatial grid
for j=1:M1
    x(j)=XL+(j-1)*h;
end
for k=1:M1
    y(k)=XL+(k-1)*h;
end
% Temporal grid
tau=0.1;tfinal=10;
T=ceil(tfinal/tau);T1=T+1;
for n=1:T1
    t(n)=(n-1)*tau;
end
% Initialize solution arrays
u=zeros(M1,M1,T1);
for j=1:M1
    for k=1:M1
        u(j,k,1)=sin(x(j))*cos(y(k));
    end
end
% Compact difference scheme coefficients
a5=16/21;a6=5/21;a7=32/63;a8=31/63;
b5=1/70;b6=8/35;b7=18/35;b8=23/3780;b9=172/945;b10=131/210;

% X-direction operators
A1X=toeplitz([b7;b6;b5;zeros(M-5,1);b5;b6]);
DXhat=toeplitz([0;-1;zeros(M-3,1);1],[0;1;zeros(M-3,1);-1])/(2*h);
DXddot=toeplitz([0;0;-1;zeros(M-5,1);1;0],[0;0;1;zeros(M-5,1);-1;0])/(4*h);
D1X=a5*DXhat+a6*DXddot;

A2X=toeplitz([b10;b9;b8;zeros(M-5,1);b8;b9]);
DX2=toeplitz([-2;1;zeros(M-3,1);1])/(h^2);
DXhat2=toeplitz([-2;0;1;zeros(M-5,1);1;0])/(4*h^2);
D2X=a7*DX2+a8*DXhat2;
H1X=inv(A1X);H2X=inv(A2X);

% Y-direction operators
A1Y=A1X;D1Y=D1X;H1Y=H1X;
A2Y=A2X;D2Y=D2X;H2Y=H2X;

% Initialize mass and energy storage
Mass=zeros(1,T1);
Energy=zeros(1,T1);

% ������ֻ�����ڲ��������
Mass(1)=h^2*sum(sum(u(1:M,1:M,1)));

% Forward difference operators for energy calculation
DX=1/h*toeplitz([-1;zeros(M-2,1);1],[-1,1,zeros(1,M-2)]);
DY=DX;
% Cholesky decomposition
Q2X=chol(H2X);Q2Y=chol(H2Y);
% Initial energy calculation
Ucurrent=u(1:M,1:M,1);
En1=sum(sum(Ucurrent.^2));
En2x=sum(sum((Q2X*DX*Ucurrent).^2));
En2y=sum(sum((Ucurrent*DY'*Q2Y').^2));
En3x=sum(sum((Q2X*DXhat*Ucurrent).^2));
En3y=sum(sum((Ucurrent*DXhat'*Q2Y').^2));
Energy(1)=h^2*(En1+alpha*(a7*(En2x+En2y)+a8*(En3x+En3y)));

fprintf('Initial condition: Mass = %.12e, Energy = %.12e\n', Mass(1), Energy(1));

% Build large sparse matrix operators
I=speye(M*M);
H2D2X=kron(speye(M),H2X*D2X);
H2D2Y=kron(H2Y*D2Y,speye(M));
H1D1X=kron(speye(M),H1X*D1X);
H1D1Y=kron(H1Y*D1Y,speye(M));
% Time stepping matrices
temp=2/tau*(I-alpha*(H2D2X+H2D2Y));
temp1=temp-beta*(H2D2X+H2D2Y)+gamma*(H1D1X+H1D1Y);

% Time stepping
fprintf('Starting time stepping...\n');
for n=1:T
    if n==1
        w=u(1:M,1:M,n);
    else
        w=3/2*u(1:M,1:M,n)-1/2*u(1:M,1:M,n-1);
    end
    
    % Iterative solution
    for k=1:100
        % Compute nonlinear term
        term1x=H1X*D1X*w;term1y=w*D1Y'*H1Y';term1=w.*(term1x+term1y);
        term2x=H1X*D1X*(w.^2);term2y=(w.^2)*D1Y'*H1Y';term2=term2x+term2y;
        nonlinearterm=(eta/3)*(term1+term2);
        
        % Build right-hand side vector
        rhsvector=temp*reshape(u(1:M,1:M,n),M*M,1)-nonlinearterm(:);
    
        % Solve linear system
        wnewvector=temp1\rhsvector;
        wnew=reshape(wnewvector,M,M);
    
        if norm(wnew-w,'fro')<1.0e-14
            break;
        end
        w=wnew;
    end
    
    % Update solution
    u(1:M,1:M,n+1)=2*w-u(1:M,1:M,n);
    
    % Periodic boundary conditions
    u(M1,:,n+1)=u(1,:,n+1);
    u(:,M1,n+1)=u(:,1,n+1);

    % ������ֻ�����ڲ��������
    Mass(n+1)=h^2*sum(sum(u(1:M,1:M,n+1)));

    Ucurrent=u(1:M,1:M,n+1);
    En1=sum(sum(Ucurrent.^2));
    En2x=sum(sum((Q2X*DX*Ucurrent).^2));
    En2y=sum(sum((Ucurrent*DY'*Q2Y').^2));
    En3x=sum(sum((Q2X*DXhat*Ucurrent).^2));
    En3y=sum(sum((Ucurrent*DXhat'*Q2Y').^2));

    Energy(n+1)=h^2*(En1+alpha*(a7*(En2x+En2y)+a8*(En3x+En3y)));

    if mod(n, 10) == 0
        fprintf('Time step %d/%d: Mass = %.12e, Energy = %.12e\n', n, T, Mass(n+1), Energy(n+1));
    end
end
toc;

% Results analysis and plotting
Ufinal=u(:,:,T1);

% Plotting
figure(1);
surf(x,y,Ufinal);
xlabel('x'); ylabel('y'); zlabel('U');
title('Numerical Solution at Final Time');

% Mass and energy evolution
figure(2);
mass_change = Mass - Mass(1);
plot(t, mass_change, 'b-', 'LineWidth', 2);
xlabel('Time'); ylabel('Mass Change');
title('Mass Conservation (Relative to Initial)');
grid on;
max_change = max(abs(mass_change));
ylim([-2*max_change, 2*max_change]);


figure(3);
plot(t, Mass, 'b-', 'LineWidth', 2);
xlabel('Time'); ylabel('Mass');
title('Mass Conservation');
grid on;
margin = max(abs(Mass-Mass(1))) * 1.5;
if margin<1e-16
    margin=1e-16; 
end
ylim([Mass(1)-margin, Mass(1) + margin]);


figure(4);
mass_error = abs(Mass-Mass(1));
semilogy(t, mass_error + 1e-20, 'b-', 'LineWidth', 2); % ��С������log(0)
xlabel('Time'); ylabel('|Mass - Mass(0)|');
title('Mass Conservation Error (Log Scale)');
grid on;

figure(5);
plot(t, Energy, 'ro-', 'LineWidth', 2);
xlabel('Time'); ylabel('Energy');
title('Energy Evolution');
grid on;

% Sample mass and energy at specific times
tplot=[0, tfinal/10, tfinal/5, 3*tfinal/10, 2*tfinal/5, tfinal/2, ...
          3*tfinal/5, 7*tfinal/10, 4*tfinal/5, 9*tfinal/10, tfinal];
indices=round(linspace(1,T1,11)); % Equally spaced 11 points
qn=Mass(indices);
en=Energy(indices);

figure(6);
plot(tplot, qn, '-or', 'LineWidth', 1.5);
xlabel('t');
ylabel('Q^{n}');
title('Scheme B - Mass');
grid on;

figure(7);
plot(tplot, en, '-or', 'LineWidth', 1.5);
xlabel('t');
ylabel('E^{n}');
title('Scheme B - Energy');
grid on;