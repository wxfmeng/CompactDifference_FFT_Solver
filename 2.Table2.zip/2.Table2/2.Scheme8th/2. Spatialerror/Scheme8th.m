%% Table 2: ʱ�������ײ��� Scheme B (�˽׸�ʽ)
clc; clear;

alf1=1; bet1=1; gam1=1; eta1=1;
XL=0; XR=1;
tfinal=1;

% �˽׸�ʽ���¸�ʽϵ��
a5=16/21; a6=5/21; a7=32/63; a8=31/63;
b5=1/70; b6=8/35; b7=18/35; b8=23/3780; b9=172/945; b10=131/210;

% �ռ䲽���������׸�ʽһ�£���֤�����ٶȣ�
h = 0.01;

% ʱ�䲽�����У���μ��룩
tau_list = [1/4, 1/8, 1/16, 1/32];

fprintf('\nTable 2: Temporal convergence for Scheme B (h = %g)\n', h);
fprintf('-------------------------------------------------------------------------------------\n');
fprintf('  tau         ||e||_2              rate      ||e||_��              rate      CPU(s)    Iter\n');
fprintf('-------------------------------------------------------------------------------------\n');

prev_L2 = [];
prev_Linf = [];

for tidx = 1:length(tau_list)
    tau = tau_list(tidx);
    
    M = ceil((XR-XL)/h);
    M1 = M + 1;
    T = ceil(tfinal/tau);
    T1 = T + 1;
    
    x = zeros(1, M1);
    for j = 1:M1
        x(j) = XL + (j-1)*h;
    end
    t = zeros(1, T1);
    for n = 1:T1
        t(n) = (n-1)*tau;
    end
    
    % ��ȷ���Դ��
    uexact = zeros(1, M1);
    f = zeros(M1, T1);
    for j = 1:M1
        uexact(j) = sin(2*pi*x(j)) * exp(-t(T1));
        for n = 1:T1
            f(j,n) = exp(-t(n)) * (2*pi*cos(2*pi*x(j)) - sin(2*pi*x(j)) ...
                     + pi*exp(-t(n))*sin(4*pi*x(j)));
        end
    end
    
    % ��ֵ
    u = zeros(M1, T1);
    for j = 1:M1
        u(j,1) = sin(2*pi*x(j));
    end
    
    % ����˽�����
    B1X = toeplitz([b7; b6; b5; zeros(M-5,1); b5; b6]);
    DXhat = toeplitz([0; -1; zeros(M-3,1); 1], [0; 1; zeros(M-3,1); -1]) / (2*h);
    DXddot = toeplitz([0; 0; -1; zeros(M-5,1); 1; 0], [0; 0; 1; zeros(M-5,1); -1; 0]) / (4*h);
    D3X = a5*DXhat + a6*DXddot;
    
    B2X = toeplitz([b10; b9; b8; zeros(M-5,1); b8; b9]);
    DX2 = toeplitz([-2; 1; zeros(M-3,1); 1]) / (h^2);
    DXhat2 = toeplitz([-2; 0; 1; zeros(M-5,1); 1; 0]) / (4*h^2);
    D4X = a7*DX2 + a8*DXhat2;
    
    I = eye(M);
    H3D3X = B1X \ D3X;
    H4D4X = B2X \ D4X;
    
    temp = 2/tau * (I - alf1*H4D4X);
    temp1 = temp - bet1*H4D4X + gam1*H3D3X;
    
    total_iter = 0;
    tic;
    for n = 1:T
        Gf = (f(1:M,n) + f(1:M,n+1)) / 2;
        if n == 1
            w = zeros(M, 1);
            w(:,1) = u(1:M,n);
        else
            w = zeros(M, 1);
            w(:,1) = 3/2 * u(1:M,n) - 1/2 * u(1:M,n-1);
        end
        
        for k = 1:1000
            temp2 = eta1/3 * (diag(w(:,k))*H3D3X + H3D3X*diag(w(:,k)));
            w(:,k+1) = temp1 \ (temp*u(1:M,n) - temp2*w(:,k) + Gf);
            if norm(w(:,k+1) - w(:,k), inf) < 1.0e-12
                break;
            end
        end
        total_iter = total_iter + k;
        u(1:M, n+1) = 2 * w(:,k+1) - u(1:M,n);
    end
    cpu_time = toc;
    avg_iter = round(total_iter / T);
    
    % �������
    uexact_end = sin(2*pi*x) * exp(-t(T1));
    error = u(:, T1)' - uexact_end;
    L2err = sqrt(h * sum(error.^2));
    Linferr = norm(error, inf);
    
    % ������
    if tidx == 1
        rate_L2 = 0;
        rate_Linf = 0;
    else
        rate_L2 = log2(prev_L2 / L2err);
        rate_Linf = log2(prev_Linf / Linferr);
    end
    prev_L2 = L2err;
    prev_Linf = Linferr;
    
    % ���
    if tidx == 1
        fprintf('  %5.1e   %.15e   %6s   %.15e   %6s   %8.3f   %5d\n', ...
                tau, L2err, '-', Linferr, '-', cpu_time, avg_iter);
    else
        fprintf('  %5.1e   %.15e   %6.4f   %.15e   %6.4f   %8.3f   %5d\n', ...
                tau, L2err, rate_L2, Linferr, rate_Linf, cpu_time, avg_iter);
    end
end

fprintf('-------------------------------------------------------------------------------------\n');